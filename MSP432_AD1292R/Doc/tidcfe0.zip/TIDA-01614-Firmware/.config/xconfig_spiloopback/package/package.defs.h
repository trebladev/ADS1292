/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_spiloopback__
#define xconfig_spiloopback__



#endif /* xconfig_spiloopback__ */ 
