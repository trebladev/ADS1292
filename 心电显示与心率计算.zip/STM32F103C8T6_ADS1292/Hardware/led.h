#ifndef __LED_H
#define __LED_H	 
#include "sys.h"



#define DS3 PBout(1) 
#define DS4 PBout(2)	

#define LEDON 0
#define LEDOFF 1

void LED_Init(void);//��ʼ��

		 				    
#endif
